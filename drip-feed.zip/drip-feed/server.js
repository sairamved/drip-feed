// server.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const app = express();
const server = http.createServer(app);

// Serve static files from /public
app.use(express.static('public'));

// ---------- WebSocket server ----------
const wss = new WebSocket.Server({ server });

let clients = new Set();

wss.on('connection', (ws, req) => {
  console.log('p5 client connected');
  clients.add(ws);

  ws.on('close', () => {
    clients.delete(ws);
    console.log('p5 client disconnected');
  });
});

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const ws of clients) {
    if (ws.readyState === WebSocket.OPEN) ws.send(msg);
  }
}

// ---------- Serial port to Arduino ----------
/*
  EDIT THIS PATH if necessary. Typical options:
   - /dev/ttyACM0
   - /dev/ttyUSB0
   - /dev/serial/by-id/...
*/
const SERIAL_PATH = '/dev/ttyACM0'; // ← change if needed
const SERIAL_BAUD = 115200;

let port;
try {
  port = new SerialPort({ path: SERIAL_PATH, baudRate: SERIAL_BAUD });
} catch (err) {
  console.error('Error opening serial port:', err.message);
  process.exit(1);
}

const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

parser.on('data', (line) => {
  const msg = String(line).trim();
  console.log('Serial <-', msg);
  if (msg === 'DRIP_END') {
    // forward to p5 clients
    broadcast({ type: 'DRIP_END' });
  }
});

// ---------- Send TICK every second to Arduino and clients ----------
setInterval(() => {
  const now = Date.now();
  const tickMsg = `TICK ${now}\n`;
  port.write(tickMsg, (err) => {
    if (err) console.error('Serial write error:', err.message);
  });
  broadcast({ type: 'TICK', time: now });
}, 1000);

// ---------- Start HTTP server ----------
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`HTTP + WS server running. Open: http://<pi-ip>:${PORT}`);
  console.log(`WebSocket internal port: same server`);
});
